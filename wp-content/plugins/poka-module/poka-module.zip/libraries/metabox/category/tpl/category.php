<table class="form-table">
	<tbody>
		<tr>
			<th scope="row"><label for="blogname">aaa</label></th>
			<td><input name="blogname" type="text" id="blogname" value="bbb" class="regular-text"></td>
		</tr>
	</tbody>
</table>