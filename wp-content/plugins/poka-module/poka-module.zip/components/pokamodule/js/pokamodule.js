jQuery(document).ready(function($) {
    $('#filter_user_id')
        .dropdown()
    ;
});